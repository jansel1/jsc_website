# Read the docs!
http://jansel.pages.dev/docs/
(When visiting our website, dont add "www." infront of it. It will not work.)

# What is JSC?

JSC is a open-source Python CLI that helps the user do various tasks such as delete files, make files, re-name them, etc.

Thanks for installing!


# JSC Alpha v0.0.0 
# Visit jansel.pages.dev/about/ to see my profile!